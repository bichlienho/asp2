﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Project.Models
{
    public class LoyaltyProgram
    {
        [Key]
        public int ProgramId { get; set; } 
        [Required]
        [ForeignKey(nameof(User))]
        public int UserId { get; set; }

        [Required]
        [Range(0, int.MaxValue, ErrorMessage = "MilesEarned must be a non-negative value.")]
        public int MilesEarned { get; set; }

        public virtual Account User { get; set; } = null!;
    }
}
