﻿using Project.Models;

namespace Project.Repository
{
    public interface IAccountRepository
    {
        Task<Account> CheckLogin(string email, string password);
        Task<Account> Register(Account account);
        Task<Account> Update(Account account);
        Task<IEnumerable<Account>> GetAllAccounts();
        Task<Account> GetAccount(int id);
        //discount
        Task<Discount> Create(Discount discount);
        Task<IEnumerable<Discount>> GetAllDisscount();
        //ticket
        Task<TicketClass> Create(TicketClass ticketClass);
        Task<IEnumerable<TicketClass>> GetAllTicketclass();
        //Flight
        Task<Flight> Create(Flight flight);
        Task<IEnumerable<Flight>> GetAllFlight();
        //airline
        Task<IEnumerable<Airline>> GetAllAirline();
        Task<Airline> Create(Airline airline);
        //airport
        Task<IEnumerable<Airport>> GetAllAirport();
        Task<IEnumerable<LoyaltyProgram>> GetAllLoyal();
        Task<LoyaltyProgram> Create(LoyaltyProgram loyaltyProgram);


    }
}
