﻿using System.ComponentModel.DataAnnotations;

namespace Project.Models
{
	public class ContactUs
	{
		[Key]
		public int Id { get; set; } // ID tự tăng

		[Required(ErrorMessage = "Phone is required.")]
		[RegularExpression(@"\d{2,}", ErrorMessage = "Phone must contain at least 2 digits.")]
		public string Phone { get; set; } // Số điện thoại

		[Required(ErrorMessage = "Name is required.")]
		[MinLength(2, ErrorMessage = "Name must contain at least 2 characters.")]
		[RegularExpression(@"^(?:\S+\s+){1}\S+$", ErrorMessage = "Name must contain at least 2 words.")]
		public string Name { get; set; } // Tên

		[Required(ErrorMessage = "Comment is required.")]
		[MinLength(3, ErrorMessage = "Comment must contain at least 3 words.")]
		public string Comment { get; set; } // Bình luận

		[Required(ErrorMessage = "Email is required.")]
		[EmailAddress(ErrorMessage = "Invalid email format.")]
		public string Email { get; set; } // Email

		public bool Status { get; set; }

		public DateTime CreatedDate { get; set; }
	}
}