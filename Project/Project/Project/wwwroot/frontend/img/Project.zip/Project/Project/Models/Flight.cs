﻿using System.ComponentModel.DataAnnotations;

namespace Project.Models
{
    public class Flight
    {

        public int FlightId { get; set; }
        [Required]
        [StringLength(100, MinimumLength = 2)]
        public string FlightNumber { get; set; } = string.Empty;

        public int AirlineId { get; set; }

        public int OriginAirportId { get; set; }

        public int DestinationAirportId { get; set; }
        [Required]
        public DateTime DepartureTime { get; set; }
        [Required]
        public DateTime ArrivalTime { get; set; }

        public virtual Airline Airline { get; set; } = null!;

        public virtual Airport OriginAirport { get; set; } = null!;

        public virtual Airport DestinationAirport { get; set; } = null!;
    }
}
