﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Project.Data;
using Project.Models;
using Project.Repository;

namespace Project.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Route("Admin/[controller]/[action]")]

    public class FlightController : Controller
    {
        private readonly IAccountRepository accountRepo;
        private readonly DatabaseContext db;
        public FlightController(IAccountRepository accountRepo, DatabaseContext db)
        {
            this.accountRepo = accountRepo;
            this.db = db;
        }
        public async Task<IActionResult> Index()
        {
            var flight = await accountRepo.GetAllFlight();

            return View(flight);
        }
        public async Task<IActionResult> Create()
        {
            ViewBag.Airlines = new SelectList(await accountRepo.GetAllAirline(), "AirlineID", "AirlineName");
            //ViewBag.OriginAirports = new SelectList(await accountRepo.GetAllAirport(), "AirportID", "AirportName");
            //ViewBag.DestinationAirports = new SelectList(await accountRepo.GetAllAirport(), "AirportID", "AirportName");
            return View();
        }


        // POST: Flight/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Flight flight)
        {
            if (ModelState.IsValid)
            {
                var createdFlight = await accountRepo.Create(flight);
                if (createdFlight != null)
                {
                    return RedirectToAction(nameof(Index)); // Chuyển về danh sách Flights sau khi tạo thành công
                }
            }

            // Nếu có lỗi, reload lại danh sách Airlines và Airports
            ViewBag.Airlines = new SelectList(await accountRepo.GetAllAirline(), "AirlineID", "AirlineName");
            //ViewBag.Airports = new SelectList(await accountRepo.GetAllAirport(), "AirportID", "AirportName");
            return View(flight);
        }


    }
}
