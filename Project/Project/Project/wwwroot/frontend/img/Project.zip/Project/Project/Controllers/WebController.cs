﻿using Microsoft.AspNetCore.Mvc;
using Project.Data;
using Project.Models;
using Project.Repository;

namespace Project.Controllers
{
    public class WebController : Controller
    {
        private readonly IAccountRepository accountRepo;
        private readonly DatabaseContext db;

        public WebController(IAccountRepository accountRepo, DatabaseContext db)
        {
            this.accountRepo = accountRepo;
            this.db = db;
        }
        //trang home
        [Route("/")]
		public IActionResult Index()
		{
			return View();
		}
		//tìm flight
		[Route("/flight")]
		public IActionResult flight()
		{
			return View();
		}
		//view all lọc chuyến bay trong 1 ngày
		[Route("/viewflight")]
		public IActionResult viewflight()
		{
			return View();
		}
        //liên hệ
        [Route("/contact")]
        public IActionResult contact()
        {
            return View();
        }
        // GET: ContactUs/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: ContactUs/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(ContactUs contact)
        {
            if (ModelState.IsValid)
            {
                db.ContactUs.Add(contact);
                db.SaveChanges();
                return RedirectToAction(nameof(Index));
            }
            return View(contact);
        }
        //trang checkout
        [Route("/booking")]
		public IActionResult booking()
		{
			return View();
		}
		//trang thông tin khuyen mai
		[Route("/discount")]
		public IActionResult discount()
		{
			return View();
		}

		//trang domestic ve may bay noi dia
		[Route("/domesticvn")]
		public IActionResult domestic()
		{
			return View();
		}
		//trang about
		[Route("/about")]
		public IActionResult about()
		{
			return View();
		}
		//trang Q&A
		[Route("/question")]
		public IActionResult QA()
		{
			return View();
		}
		//trang Support
		[Route("/support")]
		public IActionResult support()
		{
			return View();
		}
	}
}
