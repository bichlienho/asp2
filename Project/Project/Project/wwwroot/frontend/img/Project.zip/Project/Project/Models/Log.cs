﻿using System.ComponentModel.DataAnnotations;

namespace Project.Models
{
    public class Log
    {
        [Key]
        public int LogId { get; set; }

        public int UserId { get; set; }

        public string Action { get; set; } = string.Empty;

        public DateTime ActionTime { get; set; }

        public virtual Account User { get; set; } = null!;
    }
}
