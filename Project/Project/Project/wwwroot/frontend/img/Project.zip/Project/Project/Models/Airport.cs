﻿using System.ComponentModel.DataAnnotations;

namespace Project.Models
{
    public class Airport
    {
        [Key]
        public int AirportId { get; set; }
        [Required]
        [StringLength(100, MinimumLength = 2)]
        public string AirportName { get; set; } = string.Empty;
        [Required]
        [StringLength(100, MinimumLength = 2)]
        public string City { get; set; } = string.Empty;
        [Required]
        [StringLength(100, MinimumLength = 2)]
        public string Country { get; set; } = string.Empty;
    }
}
