﻿using Microsoft.EntityFrameworkCore;
using Project.Models;

namespace Project.Data
{
    public class DatabaseContext : DbContext
    {
        public DatabaseContext(DbContextOptions options) : base(options)
        {
        }
        public  DbSet<Account> Accounts { get; set; }

        public  DbSet<AccountRole> AccountRoles { get; set; }

        public  DbSet<Role> Roles { get; set; }
        public DbSet<Airline> Airlines { get; set; }
        public DbSet<Airport> Airports { get; set; }
        public DbSet<Booking> Bookings { get; set; }
        public DbSet<Cancellation> Cancellations { get; set; }
        public DbSet<Flight> Flight { get; set; }
        public DbSet<Log> Logs { get; set; }
        public DbSet<LoyaltyProgram> LoyaltyPrograms { get; set; }
        public DbSet<Payment> Payment { get; set; }
        public DbSet<Schedule> Schedules { get; set; }
        public DbSet<TicketClass> TicketClass { get; set; }
        public DbSet<Discount> Discounts { get; set; }
		public DbSet<ContactUs> ContactUs { get; set; }

		protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Account>(entity =>
            {
                entity.HasKey(e => e.Id).HasName("PK__Account__3213E83F8F5CF85F");

                entity.ToTable("Account");

                entity.Property(e => e.Id).HasColumnName("id");
                entity.Property(e => e.Fullname)
                    .HasMaxLength(100)
                    .HasColumnName("fullname");
                entity.Property(e => e.Password)
                    .HasMaxLength(100)
                    .HasColumnName("password");
                entity.Property(e => e.Username)
                    .HasMaxLength(100)
                    .HasColumnName("username");

                // Insert default data for Account
                entity.HasData(
                    new Account { Id = 1, Username = "khaihoang", Password = "$2a$12$z9tJIxjSlIdKRBt2xlvb9.AteUIvaeLaJeu10zEse2z7kku4hlzqW", Fullname = "van a",Email="khaih8375@gmail.com",PhoneNumber="0837267048", Enable = true },
                    new Account { Id = 2, Username = "khaihoang1", Password = "$2a$12$z9tJIxjSlIdKRBt2xlvb9.AteUIvaeLaJeu10zEse2z7kku4hlzqW", Fullname = "van b", Email = "khaih837@gmail.com", PhoneNumber = "0837267049", Enable = true },
                    new Account { Id = 3, Username = "demo", Password = "$2a$12$z9tJIxjSlIdKRBt2xlvb9.AteUIvaeLaJeu10zEse2z7kku4hlzqW", Fullname = "khaicute", Email = "khaih83@gmail.com", PhoneNumber = "08372670480", Enable = true }
                );
            });

            modelBuilder.Entity<AccountRole>(entity =>
            {
                entity.HasKey(e => new { e.AccountId, e.RoleId }).HasName("PK__Account___8C320947CF3D1E39");

                entity.ToTable("Account_Role");

                entity.HasOne(d => d.Account).WithMany(p => p.AccountRoles)
                    .HasForeignKey(d => d.AccountId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Account");

                entity.HasOne(d => d.Role).WithMany(p => p.AccountRoles)
                    .HasForeignKey(d => d.RoleId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Role");

                // Insert default data for AccountRole
                entity.HasData(
                    new AccountRole { AccountId = 1, RoleId = 1, Enable = true },
                    new AccountRole { AccountId = 2, RoleId = 2, Enable = true },
                    new AccountRole { AccountId = 3, RoleId = 2, Enable = true },
                    new AccountRole { AccountId = 3, RoleId = 1, Enable = true }
                );
            });

            modelBuilder.Entity<Role>(entity =>
            {
                entity.HasKey(e => e.Id).HasName("PK__Role__3213E83F7FAF5CF6");

                entity.ToTable("Role");

                entity.Property(e => e.Id).HasColumnName("id");
                entity.Property(e => e.Name)
                    .HasMaxLength(100)
                    .HasColumnName("name");

                // Insert default data for Role
                entity.HasData(
                    new Role { Id = 1, Name = "Admin" },
                    new Role { Id = 2, Name = "User" },
                     new Role { Id = 3, Name = "Demo" }
                );
            });
            modelBuilder.Entity<Flight>(entity =>
            {
                entity.HasOne(d => d.OriginAirport)
                      .WithMany()
                      .HasForeignKey(d => d.OriginAirportId)
                      .OnDelete(DeleteBehavior.Restrict);

                entity.HasOne(d => d.DestinationAirport)
                      .WithMany()
                      .HasForeignKey(d => d.DestinationAirportId)
                      .OnDelete(DeleteBehavior.Restrict);

                entity.HasOne(d => d.Airline)
                      .WithMany()
                      .HasForeignKey(d => d.AirlineId)
                      .OnDelete(DeleteBehavior.Restrict);
            });

            base.OnModelCreating(modelBuilder);
        }


    }
}
