﻿using Microsoft.AspNetCore.Mvc;
using Project.Data;
using Project.Models;
using Project.Repository;

namespace Project.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Route("Admin/[controller]/[action]")]
    public class AirlineController : Controller
    {
        private readonly IAccountRepository accountRepo;
        private readonly DatabaseContext db;

        public AirlineController(IAccountRepository accountRepo, DatabaseContext db)
        {
            this.accountRepo = accountRepo;
            this.db = db;
        }
        public async Task<IActionResult> Index()
        {
            var airline = await accountRepo.GetAllAirline();

            return View(airline);
        }
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Create(Airline airline)
        {
            if (!ModelState.IsValid)
            {

                return View(airline);
            }

            var newAccount = await accountRepo.Create(airline);

            if (newAccount != null)
            {

                return RedirectToAction("Index");
            }
            else
            {
                ViewBag.ErrorMessage = "Tạo không thành công!";
                return View(airline);
            }

        }
    }
}
