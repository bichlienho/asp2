﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Project.Data;
using Project.Models;
using Project.Repository;
using Microsoft.AspNetCore.Hosting; // Thêm namespace này

namespace Project.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Route("Admin/[controller]/[action]")]
    public class DiscountController : Controller
    {
        private readonly IAccountRepository accountRepo;
        private readonly DatabaseContext db;
        private readonly IWebHostEnvironment env; // Inject IWebHostEnvironment

        // Constructor
        public DiscountController(IAccountRepository accountRepo, DatabaseContext db, IWebHostEnvironment env)
        {
            this.accountRepo = accountRepo;
            this.db = db;
            this.env = env; // Gán giá trị cho env
        }

        // Hiển thị danh sách discount
        public async Task<IActionResult> Index()
        {
            var discounts = await accountRepo.GetAllDisscount();
            return View(discounts);
        }

        // Tạo discount
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Discount discount)
        {
            if (ModelState.IsValid)
            {
                string imagePath = string.Empty;
                if (discount.ImageFile != null)
                {
                    string filename = Path.GetFileNameWithoutExtension(discount.ImageFile.FileName);
                    string extension = Path.GetExtension(discount.ImageFile.FileName);
                    imagePath = filename + "_" + Guid.NewGuid().ToString() + extension;
                    string filePath = Path.Combine(env.WebRootPath, "Image", imagePath); // Sử dụng env.WebRootPath để lấy đường dẫn

                    // Tạo thư mục nếu chưa có
                    Directory.CreateDirectory(Path.Combine(env.WebRootPath, "Image"));

                    using (var stream = new FileStream(filePath, FileMode.Create))
                    {
                        await discount.ImageFile.CopyToAsync(stream); // Lưu file
                    }
                }

                // Thêm discount vào cơ sở dữ liệu
                var dis = new Discount
                {
                    NameCity = discount.NameCity,
                    Price = discount.Price,
                    DiscountPercent = discount.DiscountPercent,
                    QuantityDiscount = discount.QuantityDiscount,
                    Description = discount.Description,
                    Image = imagePath, // Gán đường dẫn của ảnh
                    StartDate = DateTime.Now,
                    EndDate = DateTime.Now,
                };

                db.Discounts.Add(dis);
                await db.SaveChangesAsync();

                TempData["thongbao"] = "Discount added successfully";
                return RedirectToAction("Index");
            }

            return View(discount);
        }

        // Xóa discount
        public async Task<IActionResult> Delete(int id)
        {
            var discount = await db.Discounts.SingleOrDefaultAsync(p => p.DiscountId == id);

            if (discount != null) // Kiểm tra xem discount có tồn tại không
            {
                db.Discounts.Remove(discount);
                await db.SaveChangesAsync();

                return RedirectToAction("Index");
            }

            return NotFound(); // Trả về lỗi 404 nếu không tìm thấy discount
        }
    }
}
