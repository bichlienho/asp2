﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Project.Data;
using Project.Models;
using Project.Repository;

namespace Project.Areas.Admin.Controllers
{

    [Area("Admin")]
    [Route("Admin/[controller]/[action]")]
    public class LoyalController : Controller
    {
        private readonly IAccountRepository accountRepo;
        private readonly DatabaseContext db;
        public LoyalController(IAccountRepository accountRepo, DatabaseContext db)
        {
            this.accountRepo = accountRepo;
            this.db = db;
        }
        public async Task< IActionResult> Index()
        {
            var loyal = await accountRepo.GetAllLoyal();

            return View(loyal);
        }
        [HttpGet]
        public IActionResult Create()
        {
            ViewBag.UserId = new SelectList(db.Accounts, "Id", "Username");
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Create(LoyaltyProgram loyaltyProgram)
        {
            if (!ModelState.IsValid)
            {

                return View(loyaltyProgram);
            }

            var newLoyal = await accountRepo.Create(loyaltyProgram);

            if (newLoyal != null)
            {
                ViewBag.UserId = new SelectList(db.Accounts, "Id", "Username", loyaltyProgram.UserId);
                return RedirectToAction("Index");
            }
            else
            {
                ViewBag.ErrorMessage = "Tạo không thành công!";
                return View(loyaltyProgram);
            }
        }
    }
}
