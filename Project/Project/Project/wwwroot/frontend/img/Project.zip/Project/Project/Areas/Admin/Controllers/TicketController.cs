﻿using Microsoft.AspNetCore.Mvc;
using Project.Data;
using Project.Models;
using Project.Repository;

namespace Project.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Route("Admin/[controller]/[action]")]
    public class TicketController : Controller
    {

        private readonly IAccountRepository accountRepo;
        private readonly DatabaseContext db;

        public TicketController(IAccountRepository accountRepo, DatabaseContext db)
        {
            this.accountRepo = accountRepo;
            this.db = db;
        }
        public async Task< IActionResult> Index()
        {
            var ticketClasses = await accountRepo.GetAllTicketclass();

            return View(ticketClasses);
        }
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Create(TicketClass ticketClass)
        {
            if (!ModelState.IsValid)
            {

                return View(ticketClass);
            }

            var newTicket = await accountRepo.Create(ticketClass);

            if (newTicket != null)
            {

                return RedirectToAction("Index");
            }
            else
            {
                ViewBag.ErrorMessage = "Tạo không thành công!";
                return View(ticketClass);
            }
        }
    }
}
