﻿using Microsoft.EntityFrameworkCore;
using Project.Data;
using Project.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Project.Repository
{
    public class AccountRepository:IAccountRepository
    {
        private readonly DatabaseContext db;
        public AccountRepository(DatabaseContext db)
        {
            this.db = db;
        }
        public async Task<Account> CheckLogin(string email, string password)
        {
            // Tìm tài khoản với email và kiểm tra nếu tài khoản còn hoạt động
            var account = await db.Accounts
                .Include(a => a.AccountRoles) // Bao gồm các AccountRoles (liên kết giữa tài khoản và vai trò)
                .ThenInclude(ac => ac.Role)   // Bao gồm thông tin vai trò (Role) của tài khoản
                .FirstOrDefaultAsync(a => a.Email == email && a.Enable == true); // Tìm tài khoản theo email và kiểm tra trạng thái Enable

            if (account != null)
            {
                // Nếu tìm thấy tài khoản, so sánh mật khẩu đã băm
                if (BCrypt.Net.BCrypt.Verify(password, account.Password))
                {
                    // Nếu mật khẩu chính xác, trả về tài khoản
                    return account;
                }
            }
            // Nếu không tìm thấy tài khoản hoặc mật khẩu không đúng, trả về null
            return null;
        }

        public async Task<Account> Register(Account account)
        {
            // Validate password length
            if (account.Password.Length < 4 || account.Password.Length > 30)
            {
                throw new Exception("Password must be between 4 and 30 characters.");
            }

            // Check if an account with the same email or username already exists
            var existingAccount = await db.Accounts
                .FirstOrDefaultAsync(a => a.Email == account.Email || a.Username == account.Username);

            if (existingAccount != null)
            {
                throw new Exception("An account with this email or username already exists.");
            }

            // Ensure that the PhoneNumber is not empty
            if (string.IsNullOrEmpty(account.PhoneNumber))
            {
                throw new Exception("PhoneNumber is required.");
            }

            // Hash the password before saving
            account.Password = BCrypt.Net.BCrypt.HashPassword(account.Password);

            // Set default values for other fields if needed
            account.SkyMiles = 0; // Default value
            account.Enable = true; // Default to enabled

            // Get the "User" role (assuming "Role" is a table and has a "Name" field)
            var userRole = await db.Roles
                .FirstOrDefaultAsync(r => r.Name == "User");

            if (userRole == null)
            {
                throw new Exception("The 'User' role does not exist.");
            }

            // Create an AccountRole association for the "User" role
            var accountRole = new AccountRole
            {
                Account = account,
                Role = userRole,
                Enable = true // Set to enabled by default
            };

            // Add the new account to the database
            await db.Accounts.AddAsync(account);
            await db.AccountRoles.AddAsync(accountRole); // Add the association to AccountRoles
            await db.SaveChangesAsync(); // Save both account and role associations

            return account; // Return the created account
        }


   


        public async Task<IEnumerable<Account>> GetAllAccounts()
        {
            return await db.Accounts.ToListAsync();
        }

        public async Task<Account> Update(Account account)
        { //check nó đã tồn tại chưa
            var acc = await GetAccount(account.Id);
            if (acc is null)
            {
                return null;
            }
            acc.Username = account.Username;
            acc.Fullname = account.Fullname;
            acc.Email = account.Email;
            acc.PhoneNumber = account.PhoneNumber;
            db.Accounts.Update(acc);
            await db.SaveChangesAsync();
            return account;

        }
        public async Task<Account> GetAccount(int id)
        {
            return await db.Accounts.FirstOrDefaultAsync(x => x.Id == id);
        }
        //discount
        public async Task<Discount> Create(Discount discount)
        {
            db.Discounts.Add(discount);
            int result = await db.SaveChangesAsync();
            if (result == 1)
            {
                return discount;
            }
            return null;
        }

        public async Task<IEnumerable<Discount>> GetAllDisscount()
        {
            return await db.Discounts.ToListAsync();
        }
        //ticket

        public async Task<TicketClass> Create(TicketClass ticketClass)
        {
            db.TicketClass.Add(ticketClass);
            int result = await db.SaveChangesAsync();
            if (result == 1)
            {
                return ticketClass;
            }
            return null;
        }

        public async Task<IEnumerable<TicketClass>> GetAllTicketclass()
        {
            return await db.TicketClass.ToListAsync();
        }
        //flight
        public async Task<Flight> Create(Flight flight)
        {
            db.Flight.Add(flight);
            int result = await db.SaveChangesAsync();
            if (result == 1)
            {
                return flight;
            }
            return null;
        }

        public async Task<IEnumerable<Flight>> GetAllFlight()
        {
            return await db.Flight.ToListAsync();
        }

        public async Task<IEnumerable<Airline>> GetAllAirline()
        {
            return await db.Airlines.ToListAsync();
        }

        public async Task<IEnumerable<Airport>> GetAllAirport()
        {
            return await db.Airports.ToListAsync();
        }

        public async Task<Airline> Create(Airline airline)
        {
            db.Airlines.Add(airline);
            int result = await db.SaveChangesAsync();
            if (result == 1)
            {
                return airline;
            }
            return null;
        }

        public async Task<IEnumerable<LoyaltyProgram>> GetAllLoyal()
        {
            return await db.LoyaltyPrograms.ToListAsync();
        }

        public async Task<LoyaltyProgram> Create(LoyaltyProgram loyaltyProgram)
        {
            db.LoyaltyPrograms.Add(loyaltyProgram);
            int result = await db.SaveChangesAsync();
            if (result > 0)
            {
                return loyaltyProgram;
            }
            return null;
        }
    }
}
