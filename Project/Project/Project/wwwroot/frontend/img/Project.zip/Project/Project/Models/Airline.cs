﻿using System.ComponentModel.DataAnnotations;

namespace Project.Models
{
    public class Airline
    {
        [Key]
        public int AirlineId { get; set; }
        [Required]
        [StringLength(110, MinimumLength = 2)]
        public string AirlineName { get; set; } = string.Empty;
    }
}
