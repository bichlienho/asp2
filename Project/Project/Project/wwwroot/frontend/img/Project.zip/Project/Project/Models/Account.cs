﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Project.Models;

public partial class Account
{
    public int Id { get; set; }

    [Required]
    [StringLength(20, MinimumLength = 2)]
    public string? Username { get; set; } = string.Empty;

    [StringLength(30, MinimumLength = 4)]
    public string? Password { get; set; }

    [Required]
    [StringLength(20, MinimumLength = 2)]
    public string Fullname { get; set; } = string.Empty;

    [Required]
    [EmailAddress]
    public string Email { get; set; } = string.Empty;
    [Required]
    public string? PhoneNumber { get; set; }

    public int SkyMiles { get; set; } = 0;


    public bool? Enable { get; set; } = true;

    public virtual ICollection<AccountRole> AccountRoles { get; set; } = new List<AccountRole>();
}
