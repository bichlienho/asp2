﻿using System.ComponentModel.DataAnnotations;

namespace Project.Models
{
    public class Schedule
    {
        [Key]
        public int ScheduleId { get; set; }

        [Required]
        public int FlightId { get; set; }

        [Required]
        public DateTime Date { get; set; }

        [Required]
        public int AvailableSeats { get; set; }

        [Required]
        [StringLength(100, MinimumLength = 2)]
        public string Destination { get; set; } = null!;

        [Required]
        [StringLength(100, MinimumLength = 2)]
        public string Origin { get; set; } = null!;

        public virtual Flight Flight { get; set; } = null!;
    }
}
