﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Project.Data;
using Project.EmailService;
using Project.Models;
using Project.Repository;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace Project.Areas.Admin.Controllers
{
    [Area("Admin")]
    [Route("Admin/[controller]/[action]")]
    public class AccountController : Controller
    {
        private readonly IAccountRepository accountRepo;
        private readonly DatabaseContext db;
        private readonly IEmailService _emailService; // IEmailService for sending emails
        private readonly MailSettings _mailSettings; // MailSettings for configuration

        // Constructor that injects IAccountRepository, DatabaseContext, IEmailService, and MailSettings
        public AccountController(IAccountRepository accountRepo, DatabaseContext db, IEmailService emailService, IOptions<MailSettings> mailSettings)
        {
            this.accountRepo = accountRepo;
            this.db = db;
            _emailService = emailService; // Injecting IEmailService
            _mailSettings = mailSettings.Value; // Injecting MailSettings
        }

		// GET: Admin/Account/Edit/5
		[HttpGet]
        public async Task<IActionResult> Edit(int id)
        {
            var account = await accountRepo.GetAccount(id);

            if (account == null)
            {
                return NotFound();
            }

            return View(account);
        }

        // POST: Admin/Account/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(Account account)
        {
            if (!ModelState.IsValid)
            {
                return View(account);
            }

            try
            {
                var updatedAccount = await accountRepo.Update(account);

                if (updatedAccount != null)
                {
                    ViewBag.SuccessMessage = "Account updated successfully!";
                    return RedirectToAction("Index");
                }
                else
                {
                    ModelState.AddModelError("", "Failed to update the account.");
                }
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = "An unexpected error occurred: " + ex.Message;
            }

            return View(account);
        }

        // GET: Admin/Account/Index
        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var accounts = await accountRepo.GetAllAccounts();
            return View(accounts);
        }

        // POST: Admin/Account/Delete/5
        [HttpPost]
        public async Task<IActionResult> DeleteAccount(int id)
        {
            try
            {
                var account = await db.Accounts.FindAsync(id);
                if (account == null)
                {
                    ViewBag.Error = "Account not found.";
                    return View();
                }

                using (var transaction = await db.Database.BeginTransactionAsync())
                {
                    try
                    {
                        var accountRoles = await db.AccountRoles
                            .Where(ar => ar.AccountId == id)
                            .ToListAsync();

                        if (accountRoles.Any())
                        {
                            db.AccountRoles.RemoveRange(accountRoles);
                        }

                        db.Accounts.Remove(account);
                        await db.SaveChangesAsync();
                        await transaction.CommitAsync();

                        return RedirectToAction("Index");
                    }
                    catch (Exception ex)
                    {
                        await transaction.RollbackAsync();
                        ViewBag.Error = "An error occurred while deleting the account: " + ex.Message;
                        return View();
                    }
                }
            }
            catch (Exception ex)
            {
                ViewBag.Error = "An error occurred while processing the request: " + ex.Message;
                return View();
            }
        }
    }
}
