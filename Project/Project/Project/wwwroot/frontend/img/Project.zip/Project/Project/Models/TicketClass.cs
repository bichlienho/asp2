﻿using System.ComponentModel.DataAnnotations;

namespace Project.Models
{
    public class TicketClass
    {
        [Key]
        public int TicketClassId { get; set; }

        [Required]
        [StringLength(100, MinimumLength = 2)]
        public string ClassName { get; set; } = string.Empty;

        [Required]
        public decimal Multiplier { get; set; }
    }
}
