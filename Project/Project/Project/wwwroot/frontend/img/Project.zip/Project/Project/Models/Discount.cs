﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Project.Models
{
    public class Discount
    {
        [Key]
        public int DiscountId { get; set; }

        [Required]
        public string NameCity { get; set; }

        [Required]
        public int Price { get; set; }

        [Required]
        public decimal DiscountPercent { get; set; }

        [Required]
        public int QuantityDiscount { get; set; }

        [Required]
        [StringLength(200, MinimumLength = 2)]
        public string Description { get; set; }

        public string Image { get; set; }

        [Required]
        public DateTime StartDate { get; set; }

        [Required]
        public DateTime EndDate { get; set; }

        // Thuộc tính không lưu trong cơ sở dữ liệu, chỉ dùng để upload file
        [NotMapped]
        public IFormFile ImageFile { get; set; }

        public ICollection<Booking> Bookings { get; set; } = new List<Booking>();
    }
}
